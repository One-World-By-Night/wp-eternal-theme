<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WP_ETERNAL_VERSION', '2.3.0' );
define( 'WP_ETERNAL_DIR', get_template_directory() );
define( 'WP_ETERNAL_URI', get_template_directory_uri() );

require_once WP_ETERNAL_DIR . '/inc/theme-setup.php';
require_once WP_ETERNAL_DIR . '/inc/enqueue.php';
require_once WP_ETERNAL_DIR . '/inc/elementor.php';
require_once WP_ETERNAL_DIR . '/inc/elementor-templates.php';

require_once WP_ETERNAL_DIR . '/inc/tgm/class-tgm-plugin-activation.php';
require_once WP_ETERNAL_DIR . '/inc/plugin-dependencies.php';

require_once WP_ETERNAL_DIR . '/inc/betterdocs.php';
require_once WP_ETERNAL_DIR . '/inc/tablepress.php';
require_once WP_ETERNAL_DIR . '/inc/admin.php';
