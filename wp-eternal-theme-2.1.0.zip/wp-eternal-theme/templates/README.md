# WP Eternal Theme - OWBN Template Kit

This directory contains pre-built Elementor page templates for common OWBN pages.

## Available Templates

1. **home.json** - Landing page with hero section, about block, and quick links
2. **chronicle-list.json** - Chronicle listing page using OWBN Client widget
3. **coordinator-list.json** - Coordinator listing page using OWBN Client widget
4. **bylaws.json** - Bylaws page using Bylaw Clause Manager widget
5. **voting.json** - Voting page using WP Voting Plugin widget

## How to Import Templates

### Method 1: Elementor Template Library (Recommended)

1. Go to **Templates > Saved Templates** in WordPress admin
2. Click **Import Templates**
3. Upload the desired `.json` file
4. Once imported, create a new page and select "Edit with Elementor"
5. Click the folder icon (Templates) in the Elementor panel
6. Find your imported template under "My Templates"
7. Click "Insert" to use the template

### Method 2: Direct Page Import

1. Create a new page in WordPress
2. Click "Edit with Elementor"
3. Click the three-dot menu (⋮) at the bottom left
4. Select **Import Template**
5. Upload the `.json` file
6. The template will be applied to your page

## Customization Notes

- All templates use OWBN brand colors (dark gray #1a1a1a, crimson #dc143c)
- Widget settings can be customized after import
- URLs in buttons/links should be updated to match your site structure
- Templates are fully responsive and tested on all devices

## Widget Dependencies

Each template requires specific plugins to be active:

- **chronicle-list.json** → OWBN Client plugin
- **coordinator-list.json** → OWBN Client plugin
- **bylaws.json** → Bylaw Clause Manager plugin
- **voting.json** → WP Voting Plugin

Ensure the required plugins are installed and active before importing.

## Template Updates

These templates are designed for Elementor 3.29.1+. Future updates may add new templates or improve existing ones.
