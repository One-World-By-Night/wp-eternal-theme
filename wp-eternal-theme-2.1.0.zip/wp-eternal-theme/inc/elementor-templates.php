<?php
/**
 * Elementor Theme Builder default templates.
 *
 * Creates starter header and footer templates on theme activation
 * so the site has a working Elementor-designed layout out of the box.
 * Templates are only created if none exist; re-activating the theme
 * will not duplicate them.
 *
 * @package WPEternalTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_switch_theme', 'wp_eternal_maybe_create_elementor_templates' );

/**
 * Create default Elementor Theme Builder templates if none exist.
 */
function wp_eternal_maybe_create_elementor_templates() {
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}

	wp_eternal_create_template( 'header' );
	wp_eternal_create_template( 'footer' );
	wp_eternal_create_template( 'single' );
	wp_eternal_create_template( 'archive' );
	wp_eternal_create_template( 'page' );
	wp_eternal_create_template( 'search-results' );
	wp_eternal_create_template( 'error-404' );
	wp_eternal_create_template( 'single-chronicle' );
	wp_eternal_create_template( 'single-coordinator' );
	wp_eternal_create_template( 'loop-post' );
	wp_eternal_create_template( 'loop-chronicle' );
	wp_eternal_create_template( 'loop-coordinator' );
}

/**
 * Create a single Theme Builder template if one doesn't already exist.
 *
 * @param string $type 'header' or 'footer'.
 */
function wp_eternal_create_template( $type ) {
	$existing = get_posts( array(
		'post_type'      => 'elementor_library',
		'posts_per_page' => 1,
		'post_status'    => 'any',
		'meta_query'     => array(
			array(
				'key'   => '_elementor_template_type',
				'value' => $type,
			),
		),
	) );

	if ( ! empty( $existing ) ) {
		return;
	}

	$data_fn = "wp_eternal_" . str_replace('-', '_', $type) . "_data";
	if ( ! function_exists( $data_fn ) ) {
		return;
	}

	$titles = array(
		'header'             => 'WP Eternal – Header',
		'footer'             => 'WP Eternal – Footer',
		'single'             => 'WP Eternal – Single Post',
		'archive'            => 'WP Eternal – Archive',
		'page'               => 'WP Eternal – Page',
		'search-results'     => 'WP Eternal – Search Results',
		'error-404'          => 'WP Eternal – 404 Error',
		'single-chronicle'   => 'WP Eternal – Single Chronicle',
		'single-coordinator' => 'WP Eternal – Single Coordinator',
		'loop-post'          => 'WP Eternal – Loop Post Card',
		'loop-chronicle'     => 'WP Eternal – Loop Chronicle Card',
		'loop-coordinator'   => 'WP Eternal – Loop Coordinator Card',
	);

	$title = isset( $titles[ $type ] ) ? $titles[ $type ] : 'WP Eternal Template';

	$post_id = wp_insert_post( array(
		'post_type'   => 'elementor_library',
		'post_title'  => $title,
		'post_status' => 'publish',
	) );

	if ( is_wp_error( $post_id ) ) {
		return;
	}

	// Determine conditions based on template type.
	$condition_map = array(
		'header'             => array( 'include/general' ),
		'footer'             => array( 'include/general' ),
		'single'             => array( 'include/singular/post' ),
		'archive'            => array( 'include/archive' ),
		'page'               => array( 'include/singular/page' ),
		'search-results'     => array( 'include/search' ),
		'error-404'          => array( 'include/404' ),
		'single-chronicle'   => array( 'include/singular/owbn_chronicle' ),
		'single-coordinator' => array( 'include/singular/owbn_coordinator' ),
		'loop-post'          => array( 'include/general' ), // Loop items use general condition
		'loop-chronicle'     => array( 'include/general' ),
		'loop-coordinator'   => array( 'include/general' ),
	);
	$conditions_value = isset( $condition_map[ $type ] ) ? $condition_map[ $type ] : array( 'include/general' );

	// Map custom template types to actual Elementor template types.
	$template_type_map = array(
		'single-chronicle'   => 'single',
		'single-coordinator' => 'single',
		'search-results'     => 'search-results',
		'error-404'          => 'error-404',
		'loop-post'          => 'loop-item',
		'loop-chronicle'     => 'loop-item',
		'loop-coordinator'   => 'loop-item',
	);
	$elementor_template_type = isset( $template_type_map[ $type ] ) ? $template_type_map[ $type ] : $type;

	update_post_meta( $post_id, '_elementor_template_type', $elementor_template_type );
	update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
	update_post_meta( $post_id, '_elementor_version', '3.29.1' );
	update_post_meta( $post_id, '_wp_page_template', 'default' );
	update_post_meta( $post_id, '_elementor_data', wp_json_encode( $data_fn() ) );
	update_post_meta( $post_id, '_elementor_conditions', $conditions_value );
	update_post_meta( $post_id, '_elementor_page_settings', array() );

	// Register in Elementor Pro's conditions cache so templates are active immediately.
	$conditions = get_option( 'elementor_pro_theme_builder_conditions', array() );
	if ( ! isset( $conditions[ $type ] ) ) {
		$conditions[ $type ] = array();
	}
	$conditions[ $type ][ (string) $post_id ] = $conditions_value;
	update_option( 'elementor_pro_theme_builder_conditions', $conditions );
}

// ---------- helpers ----------

/**
 * Generate a short random ID for Elementor elements.
 *
 * @return string 7-char hex string.
 */
function wp_eternal_eid() {
	return substr( md5( wp_rand() . microtime() ), 0, 7 );
}

// ---------- header template data ----------

/**
 * Build the Elementor JSON data array for the default header.
 *
 * Structure:
 *   Section  .main--header  (full-width, fixed)
 *     └─ Column 1  .site--logo--section  →  Site Logo
 *     └─ Column 2  .heade--navbar--sec   →  Nav Menu (menu-1)
 *
 * Dark-mode toggle is handled by WP Dark Mode's floating switch.
 *
 * @return array Elementor element tree.
 */
function wp_eternal_header_data() {
	return array(
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'layout'          => 'full_width',
				'stretch_section' => 'section-stretched',
				'css_classes'     => 'main--header',
				'content_position' => 'middle',
				'padding'         => array(
					'unit'     => 'px',
					'top'      => '15',
					'right'    => '30',
					'bottom'   => '15',
					'left'     => '30',
					'isLinked' => false,
				),
			),
			'elements' => array(
				// Column 1: Logo.
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 25,
						'_inline_size' => 25,
						'css_classes'  => 'site--logo--section',
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'image',
							'isInner'    => false,
							'settings'   => array(
								'image'      => array(
									'url' => 'https://www.owbn.net/sites/all/themes/owbn_responsive/images/logo/OWBN-logo_wht-red.png',
									'id'  => '',
								),
								'image_size' => 'full',
								'width'      => array(
									'unit' => 'px',
									'size' => 150,
								),
								'align'      => 'left',
								'link_to'    => 'custom',
								'link'       => array( 'url' => home_url( '/' ) ),
							),
							'elements'   => array(),
						),
					),
				),
				// Column 2: Navigation.
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 75,
						'_inline_size' => 75,
						'css_classes'  => 'heade--navbar--sec',
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'nav-menu',
							'isInner'    => false,
							'settings'   => array(
								'menu'             => '',
								'layout'           => 'horizontal',
								'align_items'      => 'flex-end',
								'pointer'          => 'none',
								'submenu_icon'     => array(
									'value'   => 'fas fa-caret-down',
									'library' => 'fa-solid',
								),
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- footer template data ----------

/**
 * Build the Elementor JSON data array for the default footer.
 *
 * @return array Elementor element tree.
 */
function wp_eternal_footer_data() {
	return array(
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'layout'          => 'full_width',
				'stretch_section' => 'section-stretched',
				'padding'         => array(
					'unit'     => 'px',
					'top'      => '20',
					'right'    => '30',
					'bottom'   => '20',
					'left'     => '30',
					'isLinked' => false,
				),
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
						'_inline_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'heading',
							'isInner'    => false,
							'settings'   => array(
								'title'       => '&copy; ' . gmdate( 'Y' ) . ' One World by Night',
								'header_size' => 'p',
								'align'       => 'center',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- single post template data ----------

/**
 * Build the Elementor JSON data array for the default single post template.
 *
 * Structure:
 *   - Featured Image
 *   - Post Title
 *   - Post Meta (author, date, categories)
 *   - Post Content
 *   - Comments
 *
 * @return array Elementor element tree.
 */
function wp_eternal_single_data() {
	return array(
		// Featured Image Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'layout' => 'full_width',
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-featured-image',
							'isInner'    => false,
							'settings'   => array(
								'link_to' => 'none',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Title and Meta Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						// Post Title.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h1',
								'align'       => 'left',
							),
							'elements'   => array(),
						),
						// Post Meta.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'post-info',
							'isInner'    => false,
							'settings'   => array(
								'view' => 'inline',
								'icon_list' => array(
									array(
										'type' => 'author',
										'icon' => array(
											'value'   => 'fas fa-user',
											'library' => 'fa-solid',
										),
										'selected_icon' => array(
											'value'   => 'fas fa-user',
											'library' => 'fa-solid',
										),
									),
									array(
										'type' => 'date',
										'icon' => array(
											'value'   => 'fas fa-calendar',
											'library' => 'fa-solid',
										),
										'selected_icon' => array(
											'value'   => 'fas fa-calendar',
											'library' => 'fa-solid',
										),
									),
									array(
										'type' => 'terms',
										'taxonomy' => 'category',
										'icon' => array(
											'value'   => 'fas fa-folder',
											'library' => 'fa-solid',
										),
										'selected_icon' => array(
											'value'   => 'fas fa-folder',
											'library' => 'fa-solid',
										),
									),
								),
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Content Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-content',
							'isInner'    => false,
							'settings'   => array(),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Comments Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-comments',
							'isInner'    => false,
							'settings'   => array(),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- archive template data ----------

/**
 * Build the Elementor JSON data array for the default archive template.
 *
 * Structure:
 *   - Archive Title & Description
 *   - Posts Archive (2-column grid)
 *
 * @return array Elementor element tree.
 */
function wp_eternal_archive_data() {
	return array(
		// Archive Header Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						// Archive Title.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'archive-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h1',
							),
							'elements'   => array(),
						),
						// Archive Description.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-archive-title',
							'isInner'    => false,
							'settings'   => array(
								'show_title'       => '',
								'show_description' => 'yes',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Posts Grid Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'archive-posts',
							'isInner'    => false,
							'settings'   => array(
								'columns'         => '2',
								'posts_per_page'  => '6',
								'show_image'      => 'yes',
								'show_title'      => 'yes',
								'show_excerpt'    => 'yes',
								'show_read_more'  => 'yes',
								'read_more_text'  => 'Read More »',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- page template data ----------

/**
 * Build the Elementor JSON data array for the default page template.
 *
 * Structure:
 *   - Page Title
 *   - Page Content (full width)
 *
 * @return array Elementor element tree.
 */
function wp_eternal_page_data() {
	return array(
		// Title Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-page-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h1',
								'align'       => 'left',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Content Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'layout' => 'full_width',
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-content',
							'isInner'    => false,
							'settings'   => array(),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- search results template data ----------

/**
 * Build the Elementor JSON data array for the search results template.
 *
 * @return array Elementor element tree.
 */
function wp_eternal_search_results_data() {
	return array(
		// Search Header Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'archive-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h1',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Search Results Grid Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'archive-posts',
							'isInner'    => false,
							'settings'   => array(
								'columns'         => '2',
								'posts_per_page'  => '10',
								'show_image'      => 'yes',
								'show_title'      => 'yes',
								'show_excerpt'    => 'yes',
								'show_read_more'  => 'yes',
								'read_more_text'  => 'Read More »',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- 404 error template data ----------

/**
 * Build the Elementor JSON data array for the 404 error template.
 *
 * @return array Elementor element tree.
 */
function wp_eternal_error_404_data() {
	return array(
		// 404 Message Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'content_position' => 'middle',
				'padding'          => array(
					'unit'     => 'px',
					'top'      => '60',
					'bottom'   => '60',
					'isLinked' => false,
				),
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						// 404 Heading.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'heading',
							'isInner'    => false,
							'settings'   => array(
								'title'       => '404',
								'header_size' => 'h1',
								'align'       => 'center',
							),
							'elements'   => array(),
						),
						// Not Found Message.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'heading',
							'isInner'    => false,
							'settings'   => array(
								'title'       => 'Page Not Found',
								'header_size' => 'h2',
								'align'       => 'center',
							),
							'elements'   => array(),
						),
						// Description Text.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor' => 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.',
								'align'  => 'center',
							),
							'elements'   => array(),
						),
						// Search Form.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'search-form',
							'isInner'    => false,
							'settings'   => array(
								'placeholder'   => 'Search...',
								'button_type'   => 'icon',
								'button_text'   => 'Search',
								'icon'          => array(
									'value'   => 'fas fa-search',
									'library' => 'fa-solid',
								),
								'skin'          => 'classic',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- single chronicle template data ----------

/**
 * Build the Elementor JSON data array for the single chronicle template.
 *
 * Uses OWBN entity widgets to display chronicle data.
 *
 * @return array Elementor element tree.
 */
function wp_eternal_single_chronicle_data() {
	return array(
		// Chronicle Title Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h1',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Chronicle Staff Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 50,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'owbn_staff',
							'isInner'    => false,
							'settings'   => array(
								'staff_type'         => 'all',
								'show_section_title' => 'yes',
								'show_email'         => 'yes',
							),
							'elements'   => array(),
						),
					),
				),
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 50,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'owbn_sessions',
							'isInner'    => false,
							'settings'   => array(
								'max_sessions' => 0,
								'show_genres'  => 'yes',
								'show_notes'   => 'yes',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Chronicle Links Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'owbn_links',
							'isInner'    => false,
							'settings'   => array(
								'link_types'          => array( 'documents', 'social', 'email' ),
								'show_icons'          => 'yes',
								'show_section_titles' => 'yes',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

// ---------- single coordinator template data ----------

/**
 * Build the Elementor JSON data array for the single coordinator template.
 *
 * Uses OWBN entity widgets to display coordinator data.
 *
 * @return array Elementor element tree.
 */
function wp_eternal_single_coordinator_data() {
	return array(
		// Coordinator Title Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h1',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Coordinator Staff Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'owbn_staff',
							'isInner'    => false,
							'settings'   => array(
								'staff_type'         => 'all',
								'show_section_title' => 'yes',
								'show_email'         => 'yes',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
		// Coordinator Links Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'owbn_links',
							'isInner'    => false,
							'settings'   => array(
								'link_types'          => array( 'documents', 'social', 'email' ),
								'show_icons'          => 'yes',
								'show_section_titles' => 'yes',
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

/**
 * Loop Post Data.
 *
 * @return array Elementor template data for loop post card.
 */
function wp_eternal_loop_post_data() {
	return array(
		// Post Card Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'background_background' => 'classic',
				'background_color'      => 'var(--owbn-newsletter-bg)',
				'border_border'         => 'solid',
				'border_width'          => array(
					'unit'   => 'px',
					'top'    => '1',
					'right'  => '1',
					'bottom' => '1',
					'left'   => '1',
				),
				'border_color'          => 'var(--owbn-medium-gray)',
				'border_radius'         => array(
					'unit'   => 'px',
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
				),
				'padding'               => array(
					'unit'   => 'px',
					'top'    => '0',
					'right'  => '0',
					'bottom' => '20',
					'left'   => '0',
				),
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						// Featured Image.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-featured-image',
							'isInner'    => false,
							'settings'   => array(
								'link_to'              => 'custom',
								'link'                 => array(
									'url'         => '',
									'is_external' => '',
								),
								'image_size'           => 'medium',
								'image_border_radius'  => array(
									'unit'   => 'px',
									'top'    => '4',
									'right'  => '4',
									'bottom' => '0',
									'left'   => '0',
								),
							),
							'elements'   => array(),
						),
						// Post Title.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-title',
							'isInner'    => false,
							'settings'   => array(
								'header_size' => 'h3',
								'link_to'     => 'custom',
								'link'        => array(
									'url'         => '',
									'is_external' => '',
								),
								'color'       => 'var(--owbn-crimson)',
								'spacing'     => array(
									'unit' => 'px',
									'top'  => '15',
									'right' => '15',
									'bottom' => '10',
									'left'  => '15',
								),
							),
							'elements'   => array(),
						),
						// Post Excerpt.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'theme-post-excerpt',
							'isInner'    => false,
							'settings'   => array(
								'excerpt_length' => 25,
								'color'          => 'var(--owbn-white)',
								'spacing'        => array(
									'unit'   => 'px',
									'top'    => '0',
									'right'  => '15',
									'bottom' => '15',
									'left'   => '15',
								),
							),
							'elements'   => array(),
						),
						// Read More Button.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'button',
							'isInner'    => false,
							'settings'   => array(
								'text'               => 'Read More',
								'link'               => array(
									'url'         => '',
									'is_external' => '',
								),
								'button_type'        => 'default',
								'button_text_color'  => 'var(--owbn-white)',
								'background_color'   => 'var(--owbn-button-primary)',
								'button_hover_color' => 'var(--owbn-button-hover)',
								'spacing'            => array(
									'unit'   => 'px',
									'top'    => '0',
									'right'  => '15',
									'bottom' => '0',
									'left'   => '15',
								),
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

/**
 * Loop Chronicle Data.
 *
 * @return array Elementor template data for loop chronicle card.
 */
function wp_eternal_loop_chronicle_data() {
	return array(
		// Chronicle Card Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'background_background' => 'classic',
				'background_color'      => 'var(--owbn-feature-box)',
				'border_border'         => 'solid',
				'border_width'          => array(
					'unit'   => 'px',
					'top'    => '2',
					'right'  => '2',
					'bottom' => '2',
					'left'   => '2',
				),
				'border_color'          => 'var(--owbn-logo-red)',
				'border_radius'         => array(
					'unit'   => 'px',
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
				),
				'padding'               => array(
					'unit'   => 'px',
					'top'    => '20',
					'right'  => '20',
					'bottom' => '20',
					'left'   => '20',
				),
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						// Chronicle Name.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'heading',
							'isInner'    => false,
							'settings'   => array(
								'title'       => '{{owbn:chronicle_name}}',
								'header_size' => 'h3',
								'color'       => 'var(--owbn-logo-red)',
							),
							'elements'   => array(),
						),
						// Location.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor'     => '<strong>Location:</strong> {{owbn:chronicle_location}}',
								'text_color' => 'var(--owbn-white)',
							),
							'elements'   => array(),
						),
						// Genre.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor'     => '<strong>Genre:</strong> {{owbn:chronicle_genre}}',
								'text_color' => 'var(--owbn-white)',
							),
							'elements'   => array(),
						),
						// Venue.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor'     => '<strong>Venue:</strong> {{owbn:chronicle_venue}}',
								'text_color' => 'var(--owbn-white)',
							),
							'elements'   => array(),
						),
						// View Chronicle Button.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'button',
							'isInner'    => false,
							'settings'   => array(
								'text'               => 'View Chronicle',
								'link'               => array(
									'url'         => '',
									'is_external' => '',
								),
								'button_type'        => 'default',
								'button_text_color'  => 'var(--owbn-white)',
								'background_color'   => 'var(--owbn-link-orange)',
								'button_hover_color' => 'var(--owbn-logo-red)',
								'spacing'            => array(
									'unit'   => 'px',
									'top'    => '15',
									'right'  => '0',
									'bottom' => '0',
									'left'   => '0',
								),
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}

/**
 * Loop Coordinator Data.
 *
 * @return array Elementor template data for loop coordinator card.
 */
function wp_eternal_loop_coordinator_data() {
	return array(
		// Coordinator Card Section.
		array(
			'id'       => wp_eternal_eid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => array(
				'background_background' => 'classic',
				'background_color'      => 'var(--owbn-feature-box)',
				'border_border'         => 'solid',
				'border_width'          => array(
					'unit'   => 'px',
					'top'    => '2',
					'right'  => '2',
					'bottom' => '2',
					'left'   => '2',
				),
				'border_color'          => 'var(--owbn-link-orange)',
				'border_radius'         => array(
					'unit'   => 'px',
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
				),
				'padding'               => array(
					'unit'   => 'px',
					'top'    => '20',
					'right'  => '20',
					'bottom' => '20',
					'left'   => '20',
				),
			),
			'elements' => array(
				array(
					'id'       => wp_eternal_eid(),
					'elType'   => 'column',
					'isInner'  => false,
					'settings' => array(
						'_column_size' => 100,
					),
					'elements' => array(
						// Coordinator Title.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'heading',
							'isInner'    => false,
							'settings'   => array(
								'title'       => '{{owbn:coordinator_title}}',
								'header_size' => 'h3',
								'color'       => 'var(--owbn-link-orange)',
							),
							'elements'   => array(),
						),
						// Type Badge.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor'     => '<span style="background: var(--owbn-logo-red); color: var(--owbn-white); padding: 4px 12px; border-radius: 3px; font-size: 12px; font-weight: bold;">{{owbn:coordinator_type}}</span>',
								'text_color' => 'var(--owbn-white)',
							),
							'elements'   => array(),
						),
						// Email.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor'     => '<strong>Contact:</strong> {{owbn:coordinator_email}}',
								'text_color' => 'var(--owbn-white)',
							),
							'elements'   => array(),
						),
						// Jurisdiction.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'text-editor',
							'isInner'    => false,
							'settings'   => array(
								'editor'     => '<strong>Jurisdiction:</strong> {{owbn:coordinator_jurisdiction}}',
								'text_color' => 'var(--owbn-white)',
							),
							'elements'   => array(),
						),
						// View Coordinator Button.
						array(
							'id'         => wp_eternal_eid(),
							'elType'     => 'widget',
							'widgetType' => 'button',
							'isInner'    => false,
							'settings'   => array(
								'text'               => 'View Details',
								'link'               => array(
									'url'         => '',
									'is_external' => '',
								),
								'button_type'        => 'default',
								'button_text_color'  => 'var(--owbn-white)',
								'background_color'   => 'var(--owbn-logo-red)',
								'button_hover_color' => 'var(--owbn-link-orange)',
								'spacing'            => array(
									'unit'   => 'px',
									'top'    => '15',
									'right'  => '0',
									'bottom' => '0',
									'left'   => '0',
								),
							),
							'elements'   => array(),
						),
					),
				),
			),
		),
	);
}
